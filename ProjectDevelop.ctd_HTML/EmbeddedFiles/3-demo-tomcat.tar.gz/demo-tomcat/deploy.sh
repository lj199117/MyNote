#!/bin/bash -e
cd "`dirname $0`"
. ./pom.sh

[ -z "$myuser" ] && myuser=myuser
if [ "$USER" != "$myuser" ]; then
	echo "please run $0 with $myuser, who am i=$USER"
	sudo -u $myuser $0 "$@"
	exit $?
fi

#1. download war, ready env
echo "deploy time: $work_time"
mkdir -p war/
war=war/$pom_a-$pom_v.war
wget "$nexus_redirect?r=$pom_r&g=$pom_g&a=$pom_a&v=$pom_v&e=war" -O $war
deploy_war

