#!/bin/bash -e
. ../../bin/env-set.sh

pom_g=com.webull.demo
pom_a=webull-demo-center
pom_v=0.1.0-SNAPSHOT
pom_r=snapshots
tomcat_user=myuser

deploy_war() {
	target_d=war/${pom_a}-${pom_v}-$work_time
	target_dir=`pwd`/$target_d
	if [ ! -f "$war" ]; then
		echo "war not exist: $war"
		exit 1
	fi
	unzip -q $war -d $target_dir
	cp -r app-conf/* $target_dir/WEB-INF/classes/
	rm -rf ${pom_a}-${pom_v}
	ln -sf $target_d ${pom_a}-${pom_v}

	./tomcat.sh stop
	echo '<?xml version="1.0" encoding="UTF-8" ?>
<Context docBase="'$target_dir'" allowLinking="true">
</Context>' > conf/Catalina/localhost/$pom_a.xml
	./tomcat.sh start
}
