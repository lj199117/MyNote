#!/bin/bash
oldpwd="`pwd`"
cd "`dirname $0`"
. ./pom.sh

[ -z "$myuser" ] && myuser=myuser
if [ "$1" != "status" ] && [ "$USER" != "$myuser" ]; then
	echo "plase run $0 with: $myuser, who am i=$USER"
	cd "$oldpwd"
	sudo -u $myuser $0 "$@"
	exit 0
fi
export CATALINA_BASE="`pwd`"
tomcat "$1" "${pom_a}"

